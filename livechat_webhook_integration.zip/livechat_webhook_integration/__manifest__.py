# -*- coding: utf-8 -*-
{
    'name': "Integración de Webhook para Live Chat",
    'summary': """
        Redirige los mensajes del Live Chat a un webhook externo y muestra la respuesta.
    """,
    'description': """
        Este módulo permite activar una integración para que los mensajes de los visitantes del sitio web 
        sean procesados por un bot externo a través de un webhook, en lugar de por los operadores de Odoo.
    """,
    'author': "Tu Nombre o Empresa",
    'website': "https://www.tuwebsite.com",
    'category': 'Website/Live Chat',
    'version': '18.0.1.0.0',
    'depends': [
        'im_livechat',  # Dependemos del módulo de Live Chat
        'website',      # El chat está en el sitio web
        'base_setup',   # Para añadir campos a los ajustes generales
    ],
    'data': [
        'data/bot_partner.xml',
        'views/res_config_settings_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}