# -*- coding: utf-8 -*-
import requests
import logging
from odoo import http
from odoo.http import request
from odoo.addons.im_livechat.controllers.main import LivechatController

_logger = logging.getLogger(__name__)

class LivechatWebhookController(LivechatController):

    @http.route('/im_livechat/chat_post', type='json', auth='public', cors='*')
    def livechat_chat_post(self, uuid, message_content, **kwargs):
        config = request.env['ir.config_parameter'].sudo()
        is_active = config.get_param('livechat_webhook_integration.is_active')
        webhook_url = config.get_param('livechat_webhook_integration.webhook_url')

        if not is_active or not webhook_url:
            # Si no está activo, se ejecuta la lógica normal de Odoo
            return super(LivechatWebhookController, self).livechat_chat_post(uuid, message_content, **kwargs)

        # Lógica del Webhook
        try:
            # Primero, dejamos que Odoo cree la sesión de chat si es necesario
            mail_channel = self._get_mail_channel(uuid, kwargs.get('visitor_username'))
            if not mail_channel:
                return False

            # Preparamos los datos para enviar al webhook
            payload = {
                'session_id': uuid,
                'user_message': message_content,
                'visitor_name': mail_channel.livechat_visitor_id.display_name,
                'channel_id': mail_channel.id,
            }
            _logger.info(f"Enviando al webhook: {payload}")

            # Llamamos al webhook
            response = requests.post(webhook_url, json=payload, timeout=15)
            response.raise_for_status() # Lanza un error si el status es 4xx o 5xx

            # Obtenemos la respuesta del bot
            response_data = response.json()
            bot_response = response_data.get('bot_message', "Lo siento, no puedo responder en este momento.")

            # Publicamos el mensaje del usuario y la respuesta del bot en el canal
            bot_author = request.env.ref('livechat_webhook_integration.partner_chatbot')
            
            # Mensaje del visitante (para que quede registro)
            mail_channel.with_context(from_odoobot=True).message_post(
                body=message_content,
                author_id=mail_channel.livechat_visitor_id.partner_id.id,
                message_type="comment",
                subtype_xmlid="mail.mt_comment"
            )
            # Respuesta del bot
            mail_channel.with_context(from_odoobot=True).message_post(
                body=bot_response,
                author_id=bot_author.id, # El mensaje viene del "Bot"
                message_type="comment",
                subtype_xmlid="mail.mt_comment"
            )
            return True

        except requests.exceptions.Timeout:
            _logger.warning("El webhook ha tardado demasiado en responder.")
            # Puedes enviar un mensaje de error al usuario si lo deseas
            return False
        except requests.exceptions.RequestException as e:
            _logger.error(f"Error al llamar al webhook: {e}")
            return False