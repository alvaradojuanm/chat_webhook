# -*- coding: utf-8 -*-
from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    is_livechat_webhook_active = fields.Boolean(
        string="Activar Webhook para Live Chat",
        config_parameter='livechat_webhook_integration.is_active'
    )
    livechat_webhook_url = fields.Char(
        string="URL del Webhook",
        config_parameter='livechat_webhook_integration.webhook_url'
    )